function pag_interface() {
    window.location.href = "/paginas/interface.html";
}

function pag_sistema() {
    window.location.href = "/paginas/sistemas.html";
}

function home() {
    window.location.href - "index.html";
}

function pag_aplicativos() {
    window.location.href = "/paginas/aplicativos.html";
}

function about() {
    window.location.href = "/paginas/sobre.html";
}